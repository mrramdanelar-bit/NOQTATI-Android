package com.example.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Fake values only, assembled from pieces so secret scanners do not flag this file. */
class RedactorTest {

    private val apiKey = "AI" + "zaSyFAKE0123456789abcdefghijklmnopq"
    private val uuid = listOf("123e4567", "e89b", "12d3", "a456", "426614174000").joinToString("-")
    private val jwt = listOf("eyJhbGciOiJSUzI1NiJ9", "eyJzdWIiOiJ0ZXN0In0", "c2lnbmF0dXJlMTIzNDU2")
        .joinToString(".")

    @Test
    fun debugTokenInLogLine() {
        val out = Redactor.redact("Firebase App Check debug token: $uuid")
        assertFalse(out, out.contains(uuid))
        assertTrue(out, out.contains("debug token") && out.contains(Redactor.MASK))
    }

    @Test
    fun debugTokenInsideFailureMessage() {
        val out = Redactor.redact("Failed to exchange debug token ($uuid). Is it registered?")
        assertFalse(out, out.contains(uuid))
        assertTrue(out, out.contains("Failed to exchange debug token"))
    }

    @Test
    fun registrationCommandKeepsProjectButHidesToken() {
        val out = Redactor.redact("firebase appcheck:debugtokens:create custom-secret-value-123 --project demo")
        assertFalse(out, out.contains("custom-secret-value-123"))
        assertTrue(out, out.endsWith("--project demo"))
    }

    @Test
    fun apiKeyInHeaderAndQuery() {
        val header = Redactor.redact("x-goog-api-key: $apiKey")
        val query = Redactor.redact("https://example.test/v1/models?key=$apiKey&alt=sse")
        assertFalse(header, header.contains(apiKey))
        assertFalse(query, query.contains(apiKey))
        assertTrue(query, query.endsWith("&alt=sse"))
    }

    @Test
    fun authorizationHeaders() {
        val bearer = Redactor.redact("Authorization: Bearer ya29.fake-token_value-123")
        val firebase = Redactor.redact("Authorization: Firebase $jwt")
        assertFalse(bearer, bearer.contains("ya29"))
        assertFalse(firebase, firebase.contains("eyJ"))
        assertTrue(bearer, bearer.startsWith("Authorization"))
    }

    @Test
    fun appCheckHeaderAndBareJwt() {
        val header = Redactor.redact("X-Firebase-AppCheck: $jwt")
        val bare = Redactor.redact("token was $jwt end")
        assertFalse(header, header.contains("eyJ"))
        assertFalse(bare, bare.contains("eyJ"))
    }

    @Test
    fun jsonFieldsKeepHarmlessValues() {
        val out = Redactor.redact("{\"token\":\"abc123def\",\"ttl\":\"3600s\"}")
        assertFalse(out, out.contains("abc123def"))
        assertTrue(out, out.contains("3600s"))
    }

    @Test
    fun privateKeyBlock() {
        val out = Redactor.redact("a\n-----BEGIN PRIVATE KEY-----\nMIIFAKE\n-----END PRIVATE KEY-----\nb")
        assertFalse(out, out.contains("MIIFAKE"))
        assertTrue(out, out.startsWith("a") && out.endsWith("b"))
    }

    @Test
    fun keystorePasswords() {
        val out = Redactor.redact("storePassword=hunter2 keyPassword: hunter3 password=hunter4")
        assertFalse(out, out.contains("hunter"))
    }

    @Test
    fun knownSecretsAreHiddenEvenWithoutAPattern() {
        val out = Redactor.redact("value s3cret-not-a-pattern here", listOf("s3cret-not-a-pattern"))
        assertEquals("value ${Redactor.MASK} here", out)
    }

    @Test
    fun longOpaqueStrings() {
        val opaque = "Zm9vYmFy" + "QUJDREVGR0hJSktMTU5PUFFSU1RVVldY" + "WVo0NTY3ODkw"
        val out = Redactor.redact("leaked $opaque here")
        assertFalse(out, out.contains(opaque))
    }

    @Test
    fun diagnosticTextIsNotDamaged() {
        val samples = listOf(
            "PERMISSION_DENIED: Firebase App Check token is invalid. code: 403",
            "com.google.firebase.ai.type.ServerException for " +
                "projects/gen-lang-client-0523103421/models/gemini-3.8-flash:generateContent",
            "Error returned from API. code: 403 body: App attestation failed.",
            "API key not valid. Please pass a valid API key.",
            "تعذر تحليل الصورة عبر الذكاء الاصطناعي",
            "1:906068471221:android:abc123"
        )
        for (sample in samples) assertEquals(sample, Redactor.redact(sample))
    }
}
