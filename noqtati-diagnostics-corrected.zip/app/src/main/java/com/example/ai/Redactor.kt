package com.example.ai

/**
 * Removes credentials from text before it is shown, copied or logged.
 *
 * Pure Kotlin (no Android dependencies) so it can be unit-tested on the JVM.
 * Rules go from most specific to most generic. Values are replaced with [MASK];
 * the field name is kept so a report still shows which kind of value was hidden.
 */
object Redactor {

    const val MASK = "[REDACTED]"

    // \x22 = double quote, \x24 = dollar sign (keeps these raw strings free of escapes).

    private val privateKeyBlock = Regex(
        """-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?(?:-----END [A-Z ]*PRIVATE KEY-----|\z)"""
    )

    /** JSON such as {"token":"..."} (App Check exchange response, OAuth responses). */
    private val jsonField = Regex(
        """(?i)(\x22(?:token|access_?token|refresh_?token|id_?token|app_?check_?token|debug_?token|""" +
            """debug_?secret|secret|client_?secret|password|api_?key|apikey|key|private_?key|""" +
            """authorization)\x22\s*:\s*)\x22[^\x22]*\x22"""
    )

    /** Headers and log fields: "X-Firebase-AppCheck: ...", "storePassword=...", "debug token: ...". */
    private val namedField = Regex(
        """(?i)\b((?:x-firebase-appcheck|x-goog-api-key|proxy-authorization|authorization|""" +
            """api[_ -]?key|access[_ -]?token|refresh[_ -]?token|id[_ -]?token|""" +
            """app[_ -]?check[_ -]?token|debug[_ -]?token|debug[_ -]?secret|client[_ -]?secret|""" +
            """store[_ -]?pass(?:word)?|key[_ -]?pass(?:word)?|password|passwd)\x22?\s*[:=]\s*)""" +
            """(?:(?:bearer|firebase|basic)\s+)?[^\s\x22',;&)]+"""
    )

    /** URL query parameters such as ?key=... */
    private val queryParam = Regex(
        """(?i)([?&](?:key|api_?key|apikey|access_token|token|auth)=)[^&\s\x22']+"""
    )

    /** "firebase appcheck:debugtokens:create <TOKEN> --project ..." */
    private val debugTokenCommand = Regex("""(?i)(appcheck:debugtokens:create\s+)\S+""")

    private val bearer = Regex("""(?i)\b((?:bearer|basic)\s+)[A-Za-z0-9._~+/=-]{8,}""")

    /** Google API keys, OAuth tokens, client secrets, GitHub tokens. */
    private val knownPrefixes = Regex(
        """\b(?:AIza[0-9A-Za-z_-]{16,}|ya29\.[0-9A-Za-z_.-]+|GOCSPX-[0-9A-Za-z_-]+|""" +
            """gh[pousr]_[0-9A-Za-z]{20,}|1//[0-9A-Za-z_-]{20,})"""
    )

    /** JWTs, which is what App Check tokens are. */
    private val jwt = Regex("""\beyJ[0-9A-Za-z_-]{8,}(?:\.[0-9A-Za-z_-]{4,}){0,2}""")

    /** Firebase App Check debug tokens are UUIDs. */
    private val uuid = Regex(
        """\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b"""
    )

    /** Last resort: a 40+ character opaque string mixing letters and digits. */
    private val longOpaque = Regex(
        """(?<![A-Za-z0-9_.\x24/-])(?=[A-Za-z0-9_+=-]*\d)(?=[A-Za-z0-9_+=-]*[A-Za-z])""" +
            """[A-Za-z0-9_+=-]{40,}(?![A-Za-z0-9_.\x24/-])"""
    )

    /**
     * @param knownSecrets exact values to hide wherever they appear (for example the
     * project's API key or the device's debug secret), even if no pattern matches them.
     */
    fun redact(text: String, knownSecrets: Collection<String> = emptyList()): String {
        var result = text
        for (secret in knownSecrets) {
            if (secret.length >= 8) result = result.replace(secret, MASK)
        }
        result = privateKeyBlock.replace(result, MASK)
        result = keepPrefix(jsonField, result) { it.groupValues[1] + "\"" + MASK + "\"" }
        for (rule in listOf(namedField, queryParam, debugTokenCommand, bearer)) {
            result = keepPrefix(rule, result) { it.groupValues[1] + MASK }
        }
        for (rule in listOf(knownPrefixes, jwt, uuid, longOpaque)) {
            result = keepPrefix(rule, result) { MASK }
        }
        return result
    }

    // A lambda replacement avoids Regex's special handling of '$' and '\' in the new text.
    private fun keepPrefix(rule: Regex, text: String, build: (MatchResult) -> String): String =
        rule.replace(text) { build(it) }
}
