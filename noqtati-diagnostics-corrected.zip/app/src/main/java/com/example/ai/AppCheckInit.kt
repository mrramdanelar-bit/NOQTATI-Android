package com.example.ai

import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.BuildConfig
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck

private const val TAG = "AppCheckInit"

/**
 * Initializes Firebase and installs the build variant's App Check provider
 * (see appCheckProviderFactory() in src/debug and src/release).
 * Returns null on success, or a user-readable diagnostic on failure.
 */
fun configureAppCheck(context: Context, intent: Intent?): String? {
    return try {
        val firebaseApp = FirebaseApp.getApps(context)
            .firstOrNull { it.name == FirebaseApp.DEFAULT_APP_NAME }
            ?: FirebaseApp.initializeApp(context)
            ?: throw IllegalStateException(
                "لم يتم العثور على إعدادات Firebase داخل التطبيق. تحقق من app/google-services.json " +
                    "ومن تطابق اسم الحزمة مع التطبيق."
            )

        // Preserve the existing device Debug token. If Firebase needs a new token,
        // the user can register it explicitly; initialization must not silently rotate it.

        val providerFactory = appCheckProviderFactory()
        FirebaseAppCheck.getInstance(firebaseApp)
            .installAppCheckProviderFactory(providerFactory)

        Log.i(
            TAG,
            "Firebase initialized successfully. projectId=${firebaseApp.options.projectId}"
        )
        Log.i(TAG, "App Check provider installed: ${providerFactory.javaClass.simpleName}")
        null
    } catch (e: Exception) {
        Log.e(TAG, "Firebase initialization/App Check setup failed", e)
        "تعذرت تهيئة Firebase: ${e.localizedMessage ?: e.javaClass.simpleName}. " +
            "تحقق من إعدادات Firebase واتصال الإنترنت."
    }
}

/**
 * Debug builds only: exchanges the device debug secret for an App Check token and
 * reports both the secret (to register in Firebase Console) and any exchange error.
 */
fun requestDebugAppCheckSecret(
    context: Context,
    onReady: (secret: String?, exchangeError: String?) -> Unit
) {
    if (!BuildConfig.DEBUG) return

    val firebaseApp = FirebaseApp.getInstance()
    FirebaseAppCheck.getInstance(firebaseApp).getAppCheckToken(false)
        .addOnCompleteListener { task ->
            val preferencesName =
                "com.google.firebase.appcheck.debug.store.${firebaseApp.persistenceKey}"
            val secret = context.getSharedPreferences(preferencesName, Context.MODE_PRIVATE)
                .getString("com.google.firebase.appcheck.debug.DEBUG_SECRET", null)
            val error = if (task.isSuccessful) {
                null
            } else {
                AiDiagnostics.redact(task.exception?.message ?: "خطأ غير معروف")
            }
            if (error != null) Log.e(TAG, "App Check token exchange failed: $error")
            onReady(secret, error)
        }
}
