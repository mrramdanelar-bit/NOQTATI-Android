package com.example.ai

import android.content.Context
import android.util.Log
import com.example.BuildConfig
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Turns AI failures into a detailed report in debug builds and into a friendly
 * Arabic message in release builds. Secrets are redacted everywhere.
 */
object AiDiagnostics {

    private const val FRIENDLY_MESSAGE =
        "تعذر تحليل الصورة عبر الذكاء الاصطناعي. تحقق من الاتصال وأعد المحاولة، " +
            "أو استخدم الوضع الأساسي دون إنترنت."

    private const val DEBUG_PREFS_PREFIX = "com.google.firebase.appcheck.debug.store."
    private const val DEBUG_SECRET_KEY = "com.google.firebase.appcheck.debug.DEBUG_SECRET"

    /** Hides credentials by pattern (see [Redactor]) and by exact known value. */
    fun redact(text: String): String = Redactor.redact(text, knownSecrets())

    /** Values that must never appear in a report: this project's API key and the device debug secret. */
    private fun knownSecrets(): List<String> = try {
        val app = FirebaseApp.getInstance()
        val prefs = app.applicationContext.getSharedPreferences(
            DEBUG_PREFS_PREFIX + app.persistenceKey,
            Context.MODE_PRIVATE
        )
        listOfNotNull(app.options.apiKey, prefs.getString(DEBUG_SECRET_KEY, null))
    } catch (e: Exception) {
        emptyList()
    }

    suspend fun describeFailure(tag: String, error: Throwable): String {
        if (!BuildConfig.DEBUG) {
            Log.e(tag, "AI analysis failed: ${error.javaClass.simpleName}")
            return FRIENDLY_MESSAGE
        }

        // Full stack trace, line by line so Logcat does not truncate it.
        redact(error.stackTraceToString()).lineSequence().forEach { Log.e(tag, it) }

        val chain = generateSequence(error) { it.cause }.take(8).toList()
        val chainText = chain.mapIndexed { index, t ->
            "[$index] ${t.javaClass.name}\n${t.message ?: "(بلا رسالة)"}"
        }.joinToString("\n")

        val appCheck = appCheckStatus()
        val allText = chainText + "\n" + appCheck
        val httpCode = Regex("(?i)code:?\\s*(\\d{3})\\b").find(allText)?.groupValues?.get(1)

        val report = buildString {
            appendLine("تشخيص (نسخة Debug فقط)")
            appendLine(chainText)
            appendLine("HTTP: ${httpCode ?: "غير متوفر من SDK"}")
            appendLine("App Check: $appCheck")
            appendLine("Package: ${BuildConfig.APPLICATION_ID}")
            appendLine("Stack trace:")
            append(error.stackTraceToString())
        }
        // The scanner's "copy details" button copies this text.
        val safeReport = redact(report).take(8000)
        Log.e(tag, "App Check: ${redact(appCheck)}")
        return safeReport
    }

    /** getAppCheckToken fails properly, unlike the interop getToken used by the SDK. */
    private suspend fun appCheckStatus(): String =
        withTimeoutOrNull(15_000L) {
            suspendCancellableCoroutine<String> { continuation ->
                try {
                    FirebaseAppCheck.getInstance().getAppCheckToken(false)
                        .addOnCompleteListener { task ->
                            val status = if (task.isSuccessful) {
                                "تم الحصول على رمز صالح"
                            } else {
                                val e = task.exception
                                "فشل: ${e?.javaClass?.name}: ${e?.message}"
                            }
                            if (continuation.isActive) continuation.resume(status)
                        }
                } catch (e: Exception) {
                    continuation.resume("تعذر الفحص: ${e.javaClass.name}: ${e.message}")
                }
            }
        } ?: "انتهت مهلة فحص App Check"
}
